import React from 'react'
import WelcomePage from './Entrys/WelcomePage'

const Home = () => {
  return (
    <div>
        <WelcomePage/>
    </div>
  )
}

export default Home